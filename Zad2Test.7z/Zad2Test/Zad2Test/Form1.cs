﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zad2Test
{
    public partial class Form1 : Form
    {
        Bitmap bm;

        const float len = 200;
        float Y0, X0, Z;// XD, YD = 120, Z;

        private void button1_Click(object sender, EventArgs e)
        {

            Ref();

            float f1, f2, f3;
            Pen br;

            try
            {
                if (textBox1.Text != string.Empty && textBox2.Text != string.Empty &&
                    textBox3.Text != string.Empty)
                {
                    f1 = Convert.ToSingle(textBox1.Text);
                    f2 = Convert.ToSingle(textBox2.Text);
                    f3 = Convert.ToSingle(textBox3.Text);
                    br = new Pen(Brushes.Red, 2);

                    PaintT(f1, f2, f3, br);
                }

                if (textBox4.Text != string.Empty && textBox5.Text != string.Empty &&
                    textBox6.Text != string.Empty)
                {
                    f1 = Convert.ToSingle(textBox4.Text);
                    f2 = Convert.ToSingle(textBox5.Text);
                    f3 = Convert.ToSingle(textBox6.Text);
                    br = new Pen(Brushes.Blue, 2);

                    PaintT(f1, f2, f3, br);
                }

                if (textBox7.Text != string.Empty && textBox8.Text != string.Empty &&
                    textBox9.Text != string.Empty)
                {
                    f1 = Convert.ToSingle(textBox7.Text);
                    f2 = Convert.ToSingle(textBox8.Text);
                    f3 = Convert.ToSingle(textBox9.Text);
                    br = new Pen(Brushes.Green, 2);

                    PaintT(f1, f2, f3, br);
                }

                pictureBox1.Image = bm;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

                
           
        }

        private void PaintT(float f1,float f2, float f3, Pen br)
        {
            Graphics g = Graphics.FromImage(bm);
            float LR = (float)Math.Pow(f2 * f2 * 400 / 2, 0.5d);
            float LL = (float)Math.Pow(f3 * f3 * 400 / 2, 0.5d);

            g.DrawLine(br, X0, Y0 - f1 * 20, X0 + LR, Y0 + LR);
            g.DrawLine(br, X0 + LR, Y0 + LR, X0 - LL, Y0 + LL);
            g.DrawLine(br, X0 - LL, Y0 + LL, X0, Y0 - f1 * 20);
        }

        public Form1()
        {
            InitializeComponent();

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Dop dp = new Dop();
            dp.Chel = 1;
            dp.Owner = this;
            dp.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Dop dp = new Dop();
            dp.Chel = 2;
            dp.Owner = this;
            dp.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Dop dp = new Dop();
            dp.Chel = 3;
            dp.Owner = this;
            dp.ShowDialog();
        }

        private void Ref()
        {
            bm = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            pictureBox1.Image = null;

            Graphics g = Graphics.FromImage(bm);

            g.DrawLine(new Pen(Brushes.Gray, 4), X0, Y0, X0, Y0 - len);

            g.DrawLine(new Pen(Brushes.Gray, 4), X0, Y0, X0 - Z, Y0 + Z);

            g.DrawLine(new Pen(Brushes.Gray, 4), X0, Y0, X0 + Z, Y0 + Z);
            pictureBox1.Image = bm;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Y0 = pictureBox1.Size.Height / 2;
            X0 = pictureBox1.Size.Width / 2;

            Z = (float)Math.Pow((len * len)/2, 0.5d);

            Ref();
            
        }
    }
}
