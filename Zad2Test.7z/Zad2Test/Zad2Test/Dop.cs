﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zad2Test
{
    public partial class Dop : Form
    {
        public int Chel;

        string[] TVin, TLov, TSil;

        public Dop()
        {
            InitializeComponent();
        }

        private void Dop_Load(object sender, EventArgs e)
        {
            switch (Chel)
            {
                case 1:
                    label1.ForeColor = Color.Red;
                    break;
                case 2:
                    label1.ForeColor = Color.Blue;
                    break;
                case 3:
                    label1.ForeColor = Color.Green;
                    break;
            }
            label1.Text = "Чувак №" + Chel;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TVin = new string[] { textBox1.Text, textBox4.Text, textBox7.Text, textBox10.Text, textBox13.Text, textBox16.Text, textBox19.Text };
            TLov = new string[] { textBox2.Text, textBox5.Text, textBox8.Text, textBox11.Text, textBox14.Text, textBox17.Text, textBox20.Text };
            TSil = new string[] { textBox3.Text, textBox6.Text, textBox9.Text, textBox12.Text, textBox15.Text, textBox18.Text, textBox21.Text };

            Form1 fr = (Form1)this.Owner;

            Zapis(TVin, fr.textBox1, fr.textBox4, fr.textBox7);

            Zapis(TLov, fr.textBox2, fr.textBox5, fr.textBox8);

            Zapis(TSil, fr.textBox3, fr.textBox6, fr.textBox9);

            this.Close();
            
        }

        private void Zapis(string[] Mas, TextBox tb1, TextBox tb2, TextBox tb3)
        {
            double count = 0, sum = 0;
            try
            {
                foreach (string s in Mas)
                {
                    if (s != string.Empty)
                    {
                        count++;
                        sum += Convert.ToDouble(s);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            switch (Chel)
            {
                case 1:
                    if(count != 0)
                    tb1.Text = (sum / count).ToString("#.##");
                    break;
                case 2:
                    if(count != 0)
                    tb2.Text = (sum / count).ToString("#.##");
                    break;
                case 3:
                    if(count != 0)
                    tb3.Text = (sum / count).ToString("#.##");
                    break;
            }
        }
    }
}
