﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorScript : MonoBehaviour {

    public int etaj;

    bool mouse = false;

    public GameObject Chel;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(mouse && Input.GetKeyDown(KeyCode.Mouse0))
        {
            Rigidbody2D rg = GetComponent<Rigidbody2D>();

            GameObject man = Instantiate(Chel, new Vector3(rg.position.x, rg.position.y - 0.1f, 1f), Quaternion.identity);
            man.GetComponent<ManScript>().etaj = etaj;
        }
	}

    private void OnMouseEnter()
    {
        mouse = true;
    }

    private void OnMouseExit()
    {
        mouse = false;
    }
}
