﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutButton : MonoBehaviour {

    bool mouse = false;
    public int etaj;
    public bool Up = true;
    //public GameObject Des;

   // private ManScript man;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
        if (mouse && Input.GetKeyDown(KeyCode.Mouse0))
        {

            GameObject lift = GameObject.Find("Lift");
            LiftScript lifts = lift.GetComponent<LiftScript>();
            if (lifts.pos == etaj)
            {
                GameObject[] Chelik = GameObject.FindGameObjectsWithTag("Chel");
                foreach (GameObject chel in Chelik)
                {
                    ManScript man = chel.GetComponent<ManScript>();
                    if (man.etaj == etaj && !man.najvntr && lifts.direction.y == 0)
                    {
                        man.direction.x = -1.0f;
                    }
                }
                if (Up)
                {
                    GameObject[] down = GameObject.FindGameObjectsWithTag("OutBut");
                    foreach (GameObject d in down)
                    {
                        OutButton ob = d.GetComponent<OutButton>();
                        if (ob.etaj == etaj)
                        {
                            Destroy(d);
                        }
                    }
                }
                else
                {
                    GameObject[] up = GameObject.FindGameObjectsWithTag("OutBut");
                    foreach (GameObject u in up)
                    {
                        OutButton ob = u.GetComponent<OutButton>();
                        if (ob.etaj == etaj)
                        {
                            Destroy(u);
                        }
                    }
                }
            }
            else
            {
                if (Up)
                {
                    lifts.ocherOU.Insert(0, etaj);
                    GameObject[] down = GameObject.FindGameObjectsWithTag("OutBut");
                    foreach (GameObject d in down)
                    {
                        OutButton ob = d.GetComponent<OutButton>();
                        if (ob.etaj == etaj)
                        {
                            Destroy(d);
                        }
                    }
                }
                else
                {
                    lifts.ocherOD.Insert(0, etaj);
                    GameObject[] up = GameObject.FindGameObjectsWithTag("OutBut");
                    foreach (GameObject u in up)
                    {
                        OutButton ob = u.GetComponent<OutButton>();
                        if (ob.etaj == etaj)
                        {
                            Destroy(u);
                        }
                    }
                }

                if (lifts.Cheliki == 0)
                {
                    if (lifts.pos > etaj && (lifts.ocherOU.Count == 1 || lifts.ocherOD.Count == 1))
                    {
                        lifts.direction.y = -1;
                        lifts.Up = false;
                        lifts.Down = true;
                    }
                    else
                    {
                        if (lifts.pos < etaj)
                        {
                            lifts.direction.y = 1;
                            lifts.Up = true;
                            lifts.Down = false;
                        }
                    }
                }
            }
            
            Destroy(gameObject);
            /*DestroyImmediate(Des, true);
            Destroy(Des);*/
        }
        
    }

    private void OnMouseEnter()
    {
        mouse = true;
    }

    private void OnMouseExit()
    {
        mouse = false;
    }

}
