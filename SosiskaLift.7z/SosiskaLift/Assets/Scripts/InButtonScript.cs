﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InButtonScript : MonoBehaviour {

    public int but = 1;
    bool mouse = false;

    void Proverka(List<int> ochers, LiftScript lifts)
    {
        
            bool prov = false;
        foreach (int i in ochers)
        {
            if (lifts.pos < i)
            {
                prov = true;
            }
        }
        if (!prov)
        {
            lifts.direction.y = -1;
            
            lifts.Up = false;
            lifts.Down = true;
        }
        else
        {
            lifts.direction.y = 1;
            lifts.Up = true;
            lifts.Down = false;
        }
        
    }


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(mouse && Input.GetKeyDown(KeyCode.Mouse0))
        {
            GameObject lift = GameObject.Find("Lift");
            LiftScript lifts = lift.GetComponent<LiftScript>();

            if (lifts.Cheliki != 0)
            {
                if (lifts.pos != but)
                {
                    GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
                    foreach (GameObject chel in chelik)
                    {

                        ManScript man = chel.GetComponent<ManScript>();

                        if (man.etaj == lifts.pos && !man.najvntr)
                        {
                            man.najvntr = true;
                            man.etaj = but;
                            
                            if(lifts.pos > but)
                            {
                                bool a = false;
                                foreach (int s in lifts.ocherD)
                                {
                                    if (s == but)
                                        a = true;
                                }
                                if (!a)
                                {
                                    lifts.ocherD.Add(but);
                                }

                                Proverka(lifts.ocherD, lifts);
                            }
                            else
                            {
                                bool a = false;
                                foreach (int s in lifts.ocherU)
                                {
                                    if (s == but)
                                        a = true;
                                }
                                if (!a)
                                {
                                    lifts.ocherU.Add(but);
                                }

                                Proverka(lifts.ocherU, lifts);

                                
                            }
                            //GameObject.Find("HeadChel").GetComponent<SpriteRenderer>().sprite.
                        }
                    }
                }
            }
        }
	}

    private void OnMouseEnter()
    {
        mouse = true;
    }

    private void OnMouseExit()
    {
        mouse = false;
    }
}
