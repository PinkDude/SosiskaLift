﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LiftOstScript : MonoBehaviour {

    //public bool Pol = true;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        GameObject lift = GameObject.Find("Lift");
        LiftScript lifts = lift.GetComponent<LiftScript>();

        if (lifts.Down)
        {

            lifts.pos = int.Parse(collision.gameObject.name);
            if (lifts.direction.y != 0)
            {
                if (lifts.ocherD.Count != 0)
                {
                    foreach (int s in lifts.ocherD)
                    {
                        if (collision.gameObject.name == s.ToString())
                        {

                            lifts.direction.y = 0;

                            GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
                            foreach (GameObject chel in chelik)
                            {
                                ManScript man = chel.GetComponent<ManScript>();
                                if (lifts.pos == man.etaj)
                                {
                                    if (man.najvntr)
                                    {
                                        man.direction.x = 1.0f;
                                        man.GetComponent<SpriteRenderer>().flipX = true;
                                        man.vis = true;
                                        man.najvntr = false;
                                        man.gameObject.layer = 9;
                                        man.animator.SetBool("Walk", true);
                                        lifts.Cheliki--;
                                    }
                                    else
                                    {
                                        man.direction.x = -1.0f;
                                        man.animator.SetBool("Walk", true);
                                    }
                                }
                            }
                            lifts.ocherD.Remove(s);
                                lifts.Up = false;
                                lifts.Down = true;
                            
                        }
                    }
                }
                else
                {
                    foreach (int s in lifts.ocherU)
                    {
                        if (collision.gameObject.name == s.ToString())
                        {

                            lifts.direction.y = 0;

                            GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
                            foreach (GameObject chel in chelik)
                            {
                                ManScript man = chel.GetComponent<ManScript>();
                                if (lifts.pos == man.etaj)
                                {
                                    if (man.najvntr)
                                    {
                                        man.direction.x = 1.0f;
                                        man.GetComponent<SpriteRenderer>().flipX = true;
                                        man.vis = true;
                                        man.najvntr = false;
                                        man.gameObject.layer = 9;
                                        man.animator.SetBool("Walk", true);
                                        lifts.Cheliki--;
                                    }
                                    else
                                    {
                                        man.direction.x = -1.0f;
                                        man.animator.SetBool("Walk", true);
                                    }
                                }
                            }
                            lifts.ocherU.Remove(s);

                            lifts.Up = true;
                            lifts.Down = false;
                        }
                    }
                }

                //if()
                
            }
        }

    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        GameObject lift = GameObject.Find("Lift");
        LiftScript lifts = lift.GetComponent<LiftScript>();

        if (lifts.Up)
        {

            lifts.pos = int.Parse(collision.gameObject.name);
            if (lifts.direction.y != 0)
            {
                if (lifts.ocherU.Count != 0)
                {
                    foreach (int s in lifts.ocherU)
                    {
                        if (collision.gameObject.name == s.ToString())
                        {

                            lifts.direction.y = 0;

                            GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
                            foreach (GameObject chel in chelik)
                            {
                                ManScript man = chel.GetComponent<ManScript>();
                                if (lifts.pos == man.etaj)
                                {
                                    if (man.najvntr)
                                    {
                                        man.direction.x = 1.0f;
                                        man.GetComponent<SpriteRenderer>().flipX = true;
                                        man.vis = true;
                                        man.najvntr = false;
                                        man.gameObject.layer = 9;
                                        man.animator.SetBool("Walk", true);
                                        lifts.Cheliki--;
                                    }
                                    else
                                    {
                                        man.direction.x = -1.0f;
                                        man.animator.SetBool("Walk", true);
                                    }
                                }
                            }
                            lifts.ocherU.Remove(s);

                            lifts.Up = true;
                            lifts.Down = false;

                            
                        }
                    }
                }
                else
                {
                    foreach (int s in lifts.ocherU)
                    {
                        if (collision.gameObject.name == s.ToString())
                        {

                            lifts.direction.y = 0;

                            GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
                            foreach (GameObject chel in chelik)
                            {
                                ManScript man = chel.GetComponent<ManScript>();
                                if (lifts.pos == man.etaj)
                                {
                                    if (man.najvntr)
                                    {
                                        man.direction.x = 1.0f;
                                        man.GetComponent<SpriteRenderer>().flipX = true;
                                        man.vis = true;
                                        man.najvntr = false;
                                        man.gameObject.layer = 9;
                                        man.animator.SetBool("Walk", true);
                                        lifts.Cheliki--;
                                    }
                                    else
                                    {
                                        man.direction.x = -1.0f;
                                        man.animator.SetBool("Walk", true);
                                    }
                                }
                            }
                            lifts.ocherU.Remove(s);
                            lifts.Up = false;
                            lifts.Down = true;
                        }
                    }
                }
            }
        }
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
