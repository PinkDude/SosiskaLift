﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LiftOstScript : MonoBehaviour {

    //public bool Pol = true;
    private void chekD(LiftScript lifts, Collider2D collision, int s)
    {
        if (collision.gameObject.name == s.ToString())
        {

            lifts.direction.y = 0;

            GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
            foreach (GameObject chel in chelik)
            {
                ManScript man = chel.GetComponent<ManScript>();
                if (lifts.pos == man.etaj)
                {
                    if (man.najvntr)
                    {
                        GameObject[] down = GameObject.FindGameObjectsWithTag("OutBut");
                        foreach (GameObject d in down)
                        {
                            OutButton ob = d.GetComponent<OutButton>();
                            if (ob.etaj == lifts.pos)
                            {
                                Destroy(d);
                            }
                        }

                        man.direction.x = 1.0f;
                        man.GetComponent<SpriteRenderer>().flipX = true;
                        man.vis = true;
                        man.najvntr = false;
                        man.gameObject.layer = 9;
                        man.animator.SetBool("Walk", true);
                    }
                    else
                    {
                        
                            man.direction.x = -1.0f;
                            man.animator.SetBool("Walk", true);
                        
                    }
                }
            }
            lifts.ocherD.Remove(s);
            lifts.ocherOD.Remove(s);
            lifts.Up = false;
            lifts.Down = true;

        }
    }

    private void chekU(LiftScript lifts, Collider2D collision, int s)
    {
        if (collision.gameObject.name == s.ToString())
        {

            lifts.direction.y = 0;

            GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");

            foreach (GameObject chel in chelik)
            {
                ManScript man = chel.GetComponent<ManScript>();

                if (lifts.pos == man.etaj)
                {
                    if (man.najvntr)
                    {
                        GameObject[] down = GameObject.FindGameObjectsWithTag("OutBut");
                        foreach (GameObject d in down)
                        {
                            OutButton ob = d.GetComponent<OutButton>();
                            if (ob.etaj == lifts.pos)
                            {
                                Destroy(d);
                            }
                        }

                        man.direction.x = 1.0f;
                        man.GetComponent<SpriteRenderer>().flipX = true;
                        man.vis = true;
                        man.najvntr = false;
                        man.gameObject.layer = 9;
                        man.animator.SetBool("Walk", true);
                    }
                    else
                    {
                            man.direction.x = -1.0f;
                            man.animator.SetBool("Walk", true);
                    }
                }
            }
            lifts.ocherU.Remove(s);
            lifts.ocherOU.Remove(s);
            lifts.Up = true;
            lifts.Down = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        GameObject lift = GameObject.Find("Lift");
        LiftScript lifts = lift.GetComponent<LiftScript>();

        if (lifts.Down)
        {

            lifts.pos = int.Parse(collision.gameObject.name);
            if (lifts.direction.y != 0)
            {
                if (lifts.ocherD.Count != 0 || lifts.ocherOD.Count != 0)
                {
                    foreach (int s in lifts.ocherD)
                    {
                        chekD(lifts, collision, s);
                    }
                    if (lifts.Cheliki < 5)
                    {
                        foreach (int s in lifts.ocherOD)
                        {
                            chekD(lifts, collision, s);
                        }
                    }
                }
                else
                {
                    foreach (int s in lifts.ocherU)
                    {
                        chekU(lifts, collision, s);
                    }
                    if (lifts.Cheliki < 5)
                    {
                        foreach (int s in lifts.ocherOU)
                        {
                            chekU(lifts, collision, s);
                        }
                    }
                }

                //if()
                
            }
        }

    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        GameObject lift = GameObject.Find("Lift");
        LiftScript lifts = lift.GetComponent<LiftScript>();

        if (lifts.Up)
        {

            lifts.pos = int.Parse(collision.gameObject.name);
            if (lifts.direction.y != 0 || lifts.ocherOU.Count != 0)
            {
                if (lifts.ocherU.Count != 0 || lifts.ocherOU.Count != 0)
                {
                    foreach (int s in lifts.ocherU)
                    {
                        chekU(lifts, collision, s);
                    }
                    if (lifts.Cheliki < 5)
                    {
                        foreach (int s in lifts.ocherOU)
                        {
                            chekU(lifts, collision, s);
                        }
                    }
                }
                else
                {
                    foreach (int s in lifts.ocherD)
                    {
                        chekD(lifts, collision, s);
                    }
                    if (lifts.Cheliki < 5)
                    {
                        foreach (int s in lifts.ocherOD)
                        {
                            chekD(lifts, collision, s);
                        }
                    }
                }
            }
        }
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
