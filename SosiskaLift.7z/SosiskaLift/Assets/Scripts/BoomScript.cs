﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoomScript : MonoBehaviour {
    
    public GameObject lift;

    bool mouse = false;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(mouse && Input.GetKeyDown(KeyCode.Mouse0))
        {
            lift.GetComponent<LiftScript>().ExDes();
        }
	}

    private void OnMouseEnter()
    {
        mouse = true;
    }

    private void OnMouseExit()
    {
        mouse = false;
    }
}
