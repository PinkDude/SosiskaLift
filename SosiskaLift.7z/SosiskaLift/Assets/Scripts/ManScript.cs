﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManScript : MonoBehaviour {
    const int maxChel = 2;

    public bool voshlift = false;

    public Vector2 speed = new Vector2(5,5);

    public Vector2 direction = new Vector2(-1, 0);

    private Vector2 movement;

    public GameObject BUP;

    public GameObject BDOWN;

    public int etaj;

    public bool najvntr = false;

    bool vnutri = false;

    public bool vis = false;

    public Animator animator;

	// Use this for initialization
	void Start () {
        animator.SetBool("Walk", true);
        
        switch(Random.Range(0, maxChel))
        {
            case 0:
                animator.SetBool("StarLordWalk", true);
                break;
            case 1:
                animator.SetBool("RedSkullWalk", true);
                break;
        }
       
    }
	
	// Update is called once per frame
	void Update () {
        GameObject lift = GameObject.FindGameObjectWithTag("Lift");
        if (lift != null)
        {
            LiftScript lifts = lift.GetComponent<LiftScript>();
            if (voshlift)
            {
                if (lifts.Down)
                {
                    if(direction.y != -1)
                    direction.y = -1;
                }
                else
                {
                    if(direction.y != 0)
                    direction.y = 0;
                }
                if(lifts.direction.y != 0)
                {
                    if(direction.x != 0)
                    {
                        animator.SetBool("Walk", false);
                        direction.x = 0;
                    }
                }
            }
        }

    
        movement = new Vector2(
            speed.x * direction.x,
            speed.y * direction.y);
	}

    private void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Chel" && !najvntr)
        {
            direction.x = 0;
            animator.SetBool("Walk", false);
        }
        
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Door")
        {
            GameObject[] go = GameObject.FindGameObjectsWithTag("Door");
            foreach (GameObject s in go)
            {
                DoorScript ds = s.GetComponent<DoorScript>();
                if (ds.etaj == etaj)
                {
                    ds.SpawnChel = false;
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        GameObject lift = GameObject.FindGameObjectWithTag("Lift");
        LiftScript lifts = lift.GetComponent<LiftScript>();
        
        if ((collision.gameObject.tag == "OutBut1") && !vis && (((lifts.pos == etaj) && (lifts.direction.y != 0)) || (lifts.pos != etaj)))
        {
            direction.x = 0;
            animator.SetBool("Walk", false);
            //float y = movement.y;
            Rigidbody2D rg = GetComponent<Rigidbody2D>();

            GameObject Bup = Instantiate(BUP,new Vector3(rg.position.x - 0.17f, rg.position.y + 0.55f, 0), Quaternion.identity);
            Bup.gameObject.GetComponent<OutButton>().etaj = etaj;

            GameObject Bdown = Instantiate(BDOWN, new Vector3(rg.position.x + 0.17f, rg.position.y + 0.55f, 0), Quaternion.identity);
            Bdown.gameObject.GetComponent<OutButton>().etaj = etaj;
        }

        if(collision.gameObject.name == "RightStena")
        {
            if (!vnutri)
            {
                GameObject.Find("HeadChel").GetComponent<SpriteRenderer>().sprite = Resources.Load<Sprite>("StarLordHead");
                GameObject.Find("Lift").GetComponent<LiftScript>().Cheliki++;
                voshlift = true;
            }
        }

        if(collision.gameObject.name == "LeftStena")
        {
            direction.x = 0;
            animator.SetBool("Walk", false);
        }

        if(collision.gameObject.tag == "Door" && vis)
        {
            Destroy(gameObject);
        }
    }
}
