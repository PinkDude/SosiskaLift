﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManScript : MonoBehaviour {

    public Vector2 speed = new Vector2(5,5);

    public Vector2 direction = new Vector2(-1, 0);

    private Vector2 movement;

    public GameObject BUP;

    public GameObject BDOWN;

    public int etaj;

    public bool najvntr = false;

    bool vnutri = false;

    public bool vis = false;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        GameObject lift = GameObject.Find("Lift");
        LiftScript lifts = lift.GetComponent<LiftScript>();
        if (najvntr)
        {
            if (lifts.Down)
            {
                direction.y = -1;
            }
            else
            {
                direction.y = 0;
            }
        }

    
        movement = new Vector2(
            speed.x * direction.x,
            speed.y * direction.y);
	}

    private void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Chel" && !najvntr)
        {
            direction.x = 0;
        }
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "OutBut" && !vis)
        {
            direction.x = 0;
            //float y = movement.y;
            Rigidbody2D rg = GetComponent<Rigidbody2D>();

            GameObject Bup = Instantiate(BUP,new Vector3(rg.position.x - 0.17f, rg.position.y + 0.55f, 0), Quaternion.identity);
            Bup.gameObject.GetComponent<OutButton>().etaj = etaj;

            GameObject Bdown = Instantiate(BDOWN, new Vector3(rg.position.x + 0.17f, rg.position.y + 0.55f, 0), Quaternion.identity);
            Bdown.gameObject.GetComponent<OutButton>().etaj = etaj;
        }

        if(collision.gameObject.name == "RightStena")
        {
            if (!vnutri)
            {
                GameObject.Find("HeadChel").GetComponent<SpriteRenderer>().sprite = Resources.Load<Sprite>("StarLordHead");
                GameObject.Find("Lift").GetComponent<LiftScript>().Cheliki++;
            }
        }

        if(collision.gameObject.name == "LeftStena")
        {
            direction.x = 0;
        }

        if(collision.gameObject.tag == "Door" && vis)
        {
            Destroy(gameObject);
        }
    }
}
