﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButCloseDScript : MonoBehaviour {

    bool mouse = false;

	// Use this for initialization
	void Start () {
		
	}

    void Proverka(List<int> ochers, LiftScript lifts)
    {
        if (ochers.Count != 0)
        {
            bool prov = false;
            foreach (int i in ochers)
            {
                if (lifts.pos < i)
                {
                    prov = true;
                }
            }
            if (!prov)
            {
                lifts.direction.y = -1;

                lifts.Up = false;
                lifts.Down = true;
            }
            else
            {
                lifts.direction.y = 1;
                lifts.Up = true;
                lifts.Down = false;
            }
        }
    }

    // Update is called once per frame
    void Update () {
		if(mouse && Input.GetKeyDown(KeyCode.Mouse0))
        {
            GameObject lift = GameObject.Find("Lift");
            LiftScript lifts = lift.GetComponent<LiftScript>();
            if (lifts.Down)
            {
                Proverka(lifts.ocherU, lifts);
                Proverka(lifts.ocherD, lifts);
            }
            else
            {
                if (lifts.Up)
                {
                    Proverka(lifts.ocherD, lifts);
                    Proverka(lifts.ocherU, lifts);
                }
            }
        }
	}

    private void OnMouseEnter()
    {
        mouse = true;
    }

    private void OnMouseExit()
    {
        mouse = false;
    }
}
