﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LiftScript : MonoBehaviour {

    public ParticleSystem smokeef;
    public ParticleSystem fireef;

    public Vector2 speed = new Vector2(0,2);

    public Vector2 direction = new Vector2(0, 0);

    public bool Up = false;

    public bool Down = false;

    public int Cheliki = 0;

    Vector2 movement;

    //public bool LMove = false;

    //bool Up = false;

    public List<int> ocherD = new List<int>();
    public List<int> ocherU = new List<int>();

    public int pos = 3;

    public void ExDes()
    {
        Transform tr = GameObject.Find("BackLift").GetComponent<Transform>();

        Instantiate(smokeef, new Vector3(tr.position.x, tr.position.y, 0), Quaternion.identity);
        Instantiate(fireef, new Vector3(tr.position.x, tr.position.y, 0), Quaternion.identity);

        GameObject[] chelik = GameObject.FindGameObjectsWithTag("Chel");
        foreach(GameObject chel in chelik)
        {
            ManScript man = chel.GetComponent<ManScript>();
            if(man.voshlift && !man.vis)
            {
                Destroy(chel);
            }
        }

        Destroy(GameObject.FindGameObjectWithTag("Lift"));
    }

	// Use this for initialization
	void Start () {
        //ochers.Clear();
	}
	
	// Update is called once per frame
	void Update () {
       // if(ochers.Count != 0)
            movement = new Vector2(
                speed.x * direction.x,
                speed.y * direction.y);
        
	}

    private void FixedUpdate()
    {
            GetComponent<Rigidbody2D>().velocity = movement;
        
    }
    
}
