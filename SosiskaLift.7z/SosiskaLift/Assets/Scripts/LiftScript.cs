﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LiftScript : MonoBehaviour {

    public Vector2 speed = new Vector2(0,2);

    public Vector2 direction = new Vector2(0, 0);

    public bool Up = false;

    public bool Down = false;

    public int Cheliki = 0;

    Vector2 movement;

    //public bool LMove = false;

    //bool Up = false;

    public List<int> ocherD = new List<int>();
    public List<int> ocherU = new List<int>();

    public int pos = 3;

	// Use this for initialization
	void Start () {
        //ochers.Clear();
	}
	
	// Update is called once per frame
	void Update () {
       // if(ochers.Count != 0)
            movement = new Vector2(
                speed.x * direction.x,
                speed.y * direction.y);
        
	}

    private void FixedUpdate()
    {
            GetComponent<Rigidbody2D>().velocity = movement;
        
    }
    
}
